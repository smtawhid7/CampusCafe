﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CafeManagementSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\CampusCafe\CafeManagementSystem\CafeDB.mdf;Integrated Security=True;Connect Timeout=30");

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
           GuestOrder Item= new GuestOrder();
            Item.Show();
        }
        public static string User;
        private void button1_Click(object sender, EventArgs e)
        {
            User=unameTb.Text;
           if(unameTb.Text==""||PasswordTb.Text=="")
            {
                MessageBox.Show ( "please enter your username or password");
            }
           else
            {
                con.Open();
                SqlDataAdapter sad = new SqlDataAdapter("select count(*) from UserTbl where Uname='"+unameTb.Text+"' and UPassword='"+PasswordTb.Text+"'",con);
                DataTable dt = new DataTable();
                sad.Fill(dt);
                if (dt.Rows[0][0].ToString()=="1")
                {
                    UserOrder Uorder = new UserOrder();
                    Uorder.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Wrong username or password");
                }
                con.Close();
            }
        }
    }
}
