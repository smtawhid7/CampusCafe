﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CafeManagementSystem
{
    public partial class UserOrder : Form
    {
        public UserOrder()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\CampusCafe\CafeManagementSystem\CafeDB.mdf;Integrated Security=True;Connect Timeout=30");
        void populate()
        {
            con.Open();
            string query = "select* from ItemTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            ItemGV.DataSource = ds.Tables[0];         //????
            con.Close();
        }
        void Filterbycategory()
        {
            con.Open();
            string query = "select* from ItemTbl where ItemCat='"+CatCb.SelectedItem.ToString()+"'";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            ItemGV.DataSource = ds.Tables[0];         //????
            con.Close();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 login = new Form1();
            login.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
             this.Hide();
            
            ItemsForm Item = new ItemsForm();
            Item.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
           // this.Hide();
           // UsersFrom ufrom = new UsersFrom();
          //  ufrom.Show();

        }
        int num = 0;
        int total, price, qty;
        string item,cat;

        private void AddToCartBtn_Click(object sender, EventArgs e)
        {
            if(QtyTb.Text=="")
            {
                MessageBox.Show("What is the Quantity");
            }
            else if (flag==0)
            {
                MessageBox.Show("Select the product to be ordered");
            }

            else
            {
                num=num+1; 
                total=price*Convert.ToInt32(QtyTb.Text);
                tabel.Rows.Add(num,item,cat,price,total);    
                OrderGV.DataSource = tabel;
                flag = 0;
            }
            sum=sum+total;
            OrderAmtLbl.Text = "" + sum;
        }

        private void ItemGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Name = ItemGV.SelectedRows[0].Cells[1].Value.ToString();
            cat = ItemGV.SelectedRows[0].Cells[2].Value.ToString();
            price= Convert.ToInt32(ItemGV.SelectedRows[0].Cells[3].Value.ToString());
            flag = 1;
        }

        private void ItemGV_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            item = ItemGV.SelectedRows[0].Cells[1].Value.ToString();
            cat = ItemGV.SelectedRows[0].Cells[2].Value.ToString();
            price = Convert.ToInt32(ItemGV.SelectedRows[0].Cells[3].Value.ToString());
            flag = 1;
        }

        DataTable tabel =new DataTable();
        int flag = 0;
        private void CatCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            Filterbycategory();
        }

        private void DateLbl_Click(object sender, EventArgs e)
        {

        }

        private void PlaceOrderBtn_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "insert into OrdersTbl values (" + OrderNumTb.Text + ",'" + DateLbl.Text + "','" + SellerNameTb.Text + "'," + OrderAmtLbl.Text + ")";
            //string query = "insert into OrdersTbl values (" + int.Parse(OrderNumTb.Text) + ",'" + DateLbl.Text + "','" + SellernameTb.Text + "'," + OrderAmtLbl.Text + ")";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Order Successfully Ctrated");
            con.Close();
            //populate();
            //reset();
        }

        private void OrderAmtLbl_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            ViewOrders view=new ViewOrders();
            view.Show();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            populate();
        }

        //int flag = 0;
        int sum = 0;
        private void UserOrder_Load(object sender, EventArgs e)
        {
            populate();
            tabel.Columns.Add("Num",typeof(int));
            tabel.Columns.Add("Item", typeof(String));
            tabel.Columns.Add("Category", typeof(String));
            tabel.Columns.Add("UnitPrice", typeof(int));
            tabel.Columns.Add("Total", typeof(int));
            OrderGV.DataSource = tabel;
            DateLbl.Text = DateTime.Today.Day.ToString() + "/" + DateTime.Today.Month.ToString() + "/" + DateTime.Today.Year.ToString();
            SellerNameTb.Text = Form1.User;
        }
    }
}
